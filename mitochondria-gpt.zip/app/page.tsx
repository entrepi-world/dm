'use client';
import React, { useEffect, useMemo, useState } from 'react';

export default function Page() {
  // --- Theme
  const colors = {
    neon: '#39FF88',
    neonAlt: '#3DFF6E',
    dark: '#0B3D2E',
    bg: '#070907',
    ink: '#E8FF57',
    grid: 'rgba(57,255,136,0.15)',
  };

  // --- State
  const [decision, setDecision] = useState('');
  const [secondsLeft, setSecondsLeft] = useState(90);
  const [phase, setPhase] = useState<'input' | 'reveal' | 'final' | 'shareView'>('input');
  const [revealStep, setRevealStep] = useState(0);
  const [frivolousMsg, setFrivolousMsg] = useState<string | null>(null);
  const [insights, setInsights] = useState<Insights | null>(null);
  const [userCall, setUserCall] = useState<'yes' | 'no' | null>(null);
  const [shareURL, setShareURL] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // On mount: check share payload
  useEffect(() => {
    try {
      const hash = window.location.hash;
      if (hash.startsWith('#d=')) {
        const b64 = decodeURIComponent(hash.slice(3));
        const json = JSON.parse(atob(b64)) as SharePayload;
        setPhase('shareView');
        setInsights(json.insights);
        setDecision(json.decision);
        setUserCall(json.userCall);
      }
    } catch {}
  }, []);

  // Timer (auto countdown)
  useEffect(() => {
    if (phase !== 'input' || secondsLeft <= 0) return;
    const id = setInterval(() => setSecondsLeft(s => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, [phase, secondsLeft]);

  // Frivolous
  useEffect(() => {
    if (phase !== 'input') return;
    setFrivolousMsg(validateDecision(decision));
  }, [decision, phase]);

  function analyze() {
    const msg = validateDecision(decision);
    if (msg) { setFrivolousMsg(msg); return; }
    const out = generateInsights(decision);
    setInsights(out);
    setPhase('reveal');
    setRevealStep(0);
  }

  function revealNext() { setRevealStep(r => Math.min(4, r + 1)); }

  function setCall(c: 'yes' | 'no') {
    setUserCall(c);
    setPhase('final');
    const url = buildShareURL({ decision, insights: insights!, userCall: c });
    setShareURL(url);
    persistHistory({ when: new Date().toISOString(), decision, insights: insights!, userCall: c });
  }

  async function copyShare() {
    if (!shareURL) return;
    await navigator.clipboard.writeText(shareURL);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }

  const history = useMemo(() => loadHistory(), [phase]);
  const timerPct = Math.round((secondsLeft / 90) * 100);

  return (
    <div className="min-h-screen w-full">
      <header className="w-full border-b border-white/10 sticky top-0 backdrop-blur bg-black/30">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-6 rounded-full" style={{ background: colors.neon }} />
            <h1 className="text-xl md:text-2xl tracking-tight font-bold lowercase">mitochondria</h1>
            <span className="text-xs md:text-sm text-white/60">decisions, made clearer</span>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8 md:py-12" style={{ fontFamily: 'Atkinson Hyperlegible, system-ui, sans-serif' }}>
        {phase === 'input' && (
          <section className="mb-8">
            <p className="text-white/80 leading-relaxed">
              We don’t tell you what to do. We show your choice through four lenses — <em>feels good</em>, <em>good for you</em>, <em>good for others</em>, <em>good for the world</em> — so you can make a clean call.
            </p>
          </section>
        )}

        {phase === 'input' && (
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <Card>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-bold text-lg">What decision are you making?</h2>
                <TimerBadge seconds={secondsLeft} pct={timerPct} accent={colors.neon} />
              </div>
              <textarea
                value={decision}
                onChange={(e) => setDecision(e.target.value)}
                placeholder="e.g., Quit my job to join a 5-person startup in Dubai"
                maxLength={280}
                className="w-full h-36 rounded-xl bg-black/40 border border-white/10 p-4 outline-none focus:border-white/20 resize-none"
              />
              {frivolousMsg && decision.length > 0 && (
                <div className="mt-4 text-amber-300/90 text-sm">{frivolousMsg}</div>
              )}
              <div className="mt-5 flex items-center gap-3">
                <button
                  onClick={analyze}
                  className="px-5 py-2.5 rounded-xl font-semibold"
                  style={{ background: `linear-gradient(135deg, ${colors.neon}, ${colors.neonAlt})`, color: '#001B12' }}
                >
                  Analyze my choice
                </button>
                <span className="text-white/50 text-sm">One-shot. Suggestive, not decisive.</span>
              </div>
            </Card>

            <Card>
              <h2 className="font-bold text-lg mb-3">How we’ll show it</h2>
              <p className="text-white/70 text-sm mb-4">A brain-shaped map with four regions. We reveal them in order from front to back. No scores, just clear prompts.</p>
              <BrainDemo colors={colors} step={0} muted />
              <ul className="mt-4 space-y-1 text-white/70 text-sm list-disc list-inside">
                <li><strong>Featherweight input</strong> — just describe the decision.</li>
                <li><strong>90s timebox</strong> — clarity loves deadlines.</li>
                <li><strong>No preaching</strong> — we surface trade-offs, you decide.</li>
              </ul>
            </Card>
          </div>
        )}

        {phase === 'reveal' && insights && (
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <Card>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-bold text-lg">Your brain map</h2>
                <span className="text-xs text-white/60">Step {Math.max(1, revealStep)}/4</span>
              </div>
              <BrainDemo colors={colors} step={revealStep} />
              <div className="mt-5 flex items-center gap-3">
                <button
                  onClick={() => setRevealStep(r => Math.min(4, r + 1))}
                  disabled={revealStep >= 4}
                  className={`px-5 py-2.5 rounded-xl font-semibold ${revealStep >= 4 ? 'opacity-50 cursor-not-allowed' : ''}`}
                  style={{ background: `linear-gradient(135deg, ${colors.neon}, ${colors.neonAlt})`, color: '#001B12' }}
                >
                  {revealStep >= 4 ? 'All revealed' : 'Reveal next'}
                </button>
                {revealStep < 4 && <span className="text-white/60 text-sm">We reveal from front → back.</span>}
              </div>
            </Card>

            <Card>
              <h2 className="font-bold text-lg">{decision.trim()}</h2>
              <div className="divide-y divide-white/10 mt-2">
                {revealStep >= 1 && <InsightRow title="Good for the world" body={insights.world} icon="🌍" />}
                {revealStep >= 2 && <InsightRow title="Good for others" body={insights.others} icon="👥" />}
                {revealStep >= 3 && <InsightRow title="Good for you" body={insights.you} icon="🧠" />}
                {revealStep >= 4 && <InsightRow title="Feels good" body={insights.feels} icon="⚡" />}
              </div>
              {revealStep >= 4 && (
                <div className="mt-5 p-3 rounded-xl border border-white/10 bg-black/30 text-white/80">
                  <strong className="block mb-1">Lens-check</strong>
                  <p className="text-sm">{insights.headline}</p>
                </div>
              )}
              {revealStep >= 4 && (
                <div className="mt-5">
                  <p className="text-white/70 text-sm mb-2">Are you making this choice now?</p>
                  <div className="flex items-center gap-2">
                    <button onClick={() => setCall('yes')} className="px-4 py-2 rounded-lg font-semibold" style={{ background: colors.neon, color: '#001B12' }}>Yes</button>
                    <button onClick={() => setCall('no')} className="px-4 py-2 rounded-lg font-semibold border border-white/20">No</button>
                  </div>
                </div>
              )}
            </Card>
          </div>
        )}

        {phase === 'final' && insights && (
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <Card>
              <h2 className="font-bold text-lg mb-2">Your brain map</h2>
              <BrainDemo colors={colors} step={4} />
            </Card>
            <Card>
              <h2 className="font-bold text-lg">{decision.trim()}</h2>
              <div className="mt-2 p-3 rounded-xl border border-white/10 bg-black/30 text-white/80">
                <strong className="block mb-1">You chose: {userCall === 'yes' ? 'Yes' : 'No'}</strong>
                <p className="text-sm">{insights.headline}</p>
              </div>
              <div className="mt-4 flex items-center gap-3">
                {shareURL ? (
                  <>
                    <button onClick={copyShare} className="px-4 py-2 rounded-lg font-semibold" style={{ background: colors.neon, color: '#001B12' }}>{copied ? 'Copied!' : 'Copy share link'}</button>
                    {'share' in navigator && (
                      <button onClick={() => navigator.share?.({ title: 'Mitochondria decision', text: 'My decision map', url: shareURL })} className="px-4 py-2 rounded-lg font-semibold border border-white/20">
                        Share…
                      </button>
                    )}
                  </>
                ) : (
                  <span className="text-white/60 text-sm">(Generate link failed)</span>
                )}
              </div>

              <div className="mt-8">
                <h3 className="font-semibold mb-2">Your history</h3>
                {history.length === 0 && <p className="text-white/60 text-sm">No saved decisions yet.</p>}
                <ul className="space-y-2">
                  {history.map((h, i) => (
                    <li key={i} className="p-3 rounded-lg border border-white/10 bg-black/20">
                      <div className="flex items-center justify-between text-xs text-white/60">
                        <span>{new Date(h.when).toLocaleString()}</span>
                        <span>Chose: <strong className="text-white/80">{h.userCall.toUpperCase()}</strong></span>
                      </div>
                      <div className="mt-1 font-medium">{h.decision}</div>
                    </li>
                  ))}
                </ul>
              </div>
            </Card>
          </div>
        )}

        {phase === 'shareView' && insights && (
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <Card>
              <h2 className="font-bold text-lg mb-2">Shared brain map</h2>
              <BrainDemo colors={colors} step={4} />
            </Card>
            <Card>
              <h2 className="font-bold text-lg">{decision.trim()}</h2>
              <div className="divide-y divide-white/10 mt-2">
                <InsightRow title="Good for the world" body={insights.world} icon="🌍" />
                <InsightRow title="Good for others" body={insights.others} icon="👥" />
                <InsightRow title="Good for you" body={insights.you} icon="🧠" />
                <InsightRow title="Feels good" body={insights.feels} icon="⚡" />
              </div>
              <div className="mt-5 p-3 rounded-xl border border-white/10 bg-black/30 text-white/80">
                <strong className="block mb-1">Lens-check</strong>
                <p className="text-sm">{insights.headline}</p>
              </div>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl p-5 md:p-6 border border-white/10 bg-black/30 shadow-[0_0_0_1px_rgba(255,255,255,0.03)]">{children}</div>;
}

function TimerBadge({ seconds, pct, accent }: { seconds: number; pct: number; accent: string }) {
  const ring = `conic-gradient(${accent} ${pct}%, rgba(255,255,255,0.08) ${pct}%)`;
  return (
    <div className="flex items-center gap-2">
      <div className="w-7 h-7 rounded-full grid place-items-center" style={{ background: ring }}>
        <div className="w-[22px] h-[22px] rounded-full bg-black/80 grid place-items-center text-[10px] font-bold" style={{ color: accent }}>
          {seconds}
        </div>
      </div>
      <span className="text-xs text-white/60">90s</span>
    </div>
  );
}

function InsightRow({ title, body, icon }: { title: string; body: string; icon: string }) {
  return (
    <div className="py-3">
      <div className="text-sm uppercase tracking-wide text-white/50 mb-1">{icon} {title}</div>
      <p className="text-white/90 leading-relaxed text-[15px]">{body}</p>
    </div>
  );
}

function BrainDemo({ colors, step, muted = false }: { colors: any; step: number; muted?: boolean }) {
  const alpha = (n: number) => (step >= n ? 1 : 0.2);
  const stroke = muted ? 'rgba(255,255,255,0.2)' : 'rgba(255,255,255,0.4)';
  return (
    <div className="w-full aspect-[4/3] rounded-2xl border border-white/10 bg-black/30 grid place-items-center">
      <svg viewBox="0 0 320 240" className="w-[92%]">
        <defs>
          <linearGradient id="gWorld" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={colors.neon} />
            <stop offset="100%" stopColor={colors.neonAlt} />
          </linearGradient>
          <linearGradient id="gMid" x1="1" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={colors.dark} />
            <stop offset="100%" stopColor={colors.neon} />
          </linearGradient>
        </defs>
        <ellipse cx="160" cy="120" rx="135" ry="95" fill="none" stroke={stroke} strokeWidth="2" />
        <path d="M60,120 C60,70 110,50 160,50 C210,50 260,70 260,120 C220,120 180,120 160,120 C140,120 100,120 60,120 Z" fill="url(#gWorld)" opacity={alpha(1)} />
        <path d="M60,120 C60,170 110,190 160,190 C160,160 160,140 160,120 C140,120 100,120 60,120 Z" fill="url(#gMid)" opacity={alpha(2)} />
        <path d="M160,120 C180,120 220,120 260,120 C260,170 210,190 160,190 C160,160 160,140 160,120 Z" fill="url(#gMid)" opacity={alpha(3)} />
        <path d="M60,120 C60,70 110,50 160,50 C210,50 260,70 260,120 C220,120 180,120 160,120 C140,120 100,120 60,120 Z" fill={colors.ink} opacity={alpha(4) * 0.25} />
        <text x="160" y="28" textAnchor="middle" fill="rgba(255,255,255,0.75)" fontSize="12">good for the world</text>
        <text x="28" y="126" textAnchor="start" fill="rgba(255,255,255,0.75)" fontSize="12">good for others</text>
        <text x="292" y="126" textAnchor="end" fill="rgba(255,255,255,0.75)" fontSize="12">good for you</text>
        <text x="160" y="220" textAnchor="middle" fill="rgba(255,255,255,0.75)" fontSize="12">feels good</text>
      </svg>
    </div>
  );
}

// --- Logic
type Insights = {
  world: string;
  others: string;
  you: string;
  feels: string;
  headline: string;
};

type SharePayload = {
  decision: string;
  userCall: 'yes' | 'no';
  insights: Insights;
};

type HistoryItem = SharePayload & { when: string };

function validateDecision(text: string): string | null {
  const t = text.trim();
  if (t.length < 12) return 'Add a bit more context (verb + object). Example: “Switch from MBA to a tech bootcamp in Jan.”';
  if (/(idk|don\'t know|whatever|blah|asdf|test|jk|lol|nothing)/i.test(t)) return 'Try a real decision. Aim for a concrete action and target.';
  if (!/[a-zA-Z]/.test(t)) return 'Use words, not just symbols.';
  return null;
}

function generateInsights(text: string): Insights {
  const t = text.toLowerCase();
  const feelsHits = /(fun|enjoy|pleasure|party|binge|scroll|shop|buy|spontaneous|novel|exciting|immediate)/.test(t);
  const youHits = /(health|sleep|career|learn|study|exercise|save|invest|skill|discipline|future|degree|portfolio|focus)/.test(t);
  const othersHits = /(team|family|friend|customers|students|parents|colleagues|community|users|employees|partner)/.test(t);
  const worldHits = /(environment|climate|carbon|sustainability|ethical|ethics|privacy|safety|inclusion|equity|open|education|public|policy|recycle|pollution)/.test(t);

  const world = worldPrompt(text, worldHits);
  const others = othersPrompt(text, othersHits);
  const you = youPrompt(text, youHits);
  const feels = feelsPrompt(text, feelsHits);

  const dominant = [
    { key: 'good for the world', v: worldHits ? 2 : 0 },
    { key: 'good for others', v: othersHits ? 2 : 0 },
    { key: 'good for you', v: youHits ? 2 : 0 },
    { key: 'feels good', v: feelsHits ? 2 : 0 },
  ].sort((a, b) => b.v - a.v);

  const weakest = [
    { key: 'good for the world', v: worldHits ? 2 : 0 },
    { key: 'good for others', v: othersHits ? 2 : 0 },
    { key: 'good for you', v: youHits ? 2 : 0 },
    { key: 'feels good', v: feelsHits ? 2 : 0 },
  ].sort((a, b) => a.v - b.v);

  const headline = `For this choice, the clearest pull seems to be “${dominant[0].key}”. Before you decide, give a moment to “${weakest[0].key}” so the trade-off is intentional.`;
  return { world, others, you, feels, headline };
}

function worldPrompt(text: string, hit: boolean): string {
  if (hit) return `Zoom out: how does “${text.trim()}” move the needle beyond you — on fairness, safety, or sustainability? Keep it practical: one small downstream effect you’d be proud to create.`;
  return `Quick lens check on the wider world: If a million people copied your move — “${text.trim()}” — what small net effect would ripple outward? If none, note it; neutrality is also a choice.`;
}
function othersPrompt(text: string, hit: boolean): string {
  if (hit) return `Name the people most affected by “${text.trim()}”. What changes for them next week? If trade-offs exist, write one way you’ll make it easier on them.`;
  return `Think socially: who notices “${text.trim()}” first — family, teammates, customers? Jot one courtesy you’ll extend so they aren’t surprised.`;
}
function youPrompt(text: string, hit: boolean): string {
  if (hit) return `Future-you check: six months from now, what skill, health, or stability gain will “${text.trim()}” lock in? Write one thing you’ll measure to stay honest.`;
  return `Future-you check: what do you stand to learn or strengthen if you proceed with “${text.trim()}”? Note one way you’ll protect energy or finances while doing it.`;
}
function feelsPrompt(text: string, hit: boolean): string {
  if (hit) return `Name the immediate pull in “${text.trim()}” — comfort, novelty, relief, or thrill. Keep it in view so it doesn’t steer the whole ship.`;
  return `Gut scan: what’s the instant feeling around “${text.trim()}” — relief, fear, excitement? Let it speak, then invite the other lenses to weigh in.`;
}

function buildShareURL(payload: SharePayload): string {
  const b64 = btoa(JSON.stringify(payload));
  const base = window.location.origin + window.location.pathname;
  return `${base}#d=${encodeURIComponent(b64)}`;
}
function persistHistory(item: HistoryItem) {
  try {
    const key = 'mitochondria.decisions';
    const raw = localStorage.getItem(key);
    const arr: HistoryItem[] = raw ? JSON.parse(raw) : [];
    arr.unshift(item);
    localStorage.setItem(key, JSON.stringify(arr.slice(0, 50)));
  } catch {}
}
function loadHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem('mitochondria.decisions');
    return raw ? (JSON.parse(raw) as HistoryItem[]) : [];
  } catch { return []; }
}
